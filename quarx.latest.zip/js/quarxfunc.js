/**
 * Quarx
 *
 * A modular application framework built on CodeIgniter
 *
 * @package     Quarx
 * @author      Matt Lantz
 * @copyright   Copyright (c) 2013 Matt Lantz
 * @license     http://ottacon.co/quarx/license.html
 * @link        http://ottacon.co/quarx
 * @since       Version 1.0
 * 
 */

function resetSearch(){
    $('#quarx-search').val('');
    $('#quarx-search').css('color','#222');
}

// Profile Image resizing
function profileImageResize(){
    var width = $('.quarx-profile-image-box img').width(),
        height = $('.quarx-profile-image-box img').height();

    if(height == width){
        $('.quarx-profile-image-box img').css({
            marginTop: 15,
            marginLeft: ($('.quarx-profile-image-box img').parent().width() - 320)/2,
            height: 320,
            width: 320
        });
    }

    else if(height > width){
        var newWidth = ( width * 320 ) / height,
            marginLeft = ($('.quarx-profile-image-box img').parent().width() - newWidth)/2,
            marginTop = (350 - 320)/2;

        $('.quarx-profile-image-box img').css({
            marginTop: marginTop,
            marginLeft: marginLeft,
            height: 320,
            width: newWidth
        });
    }

    else if(width > height){

        var newHeight = ( height/width ) * 350,
            marginTop = (350 - newHeight)/2,
            marginLeft = ($('.quarx-profile-image-box img').parent().width() - 350)/2;

        $('.quarx-profile-image-box img').css({
            marginTop: marginTop,
            marginLeft: marginLeft,
            width: 320,
            height: newHeight
        });
    }
}

// Profile Image resizing
function thumbnailImageResize(){
    $('.quarx-img-thumb-holder img').each(function(){
        var width = $(this).width(),
            height = $(this).height();

        if(height === width){
            $(this).css({
                marginTop: -10,
                marginLeft: 0,
                height: 114,
                width: 114
            });
        }

        if(height > width){
            var newWidth = ( width * 114 ) / height,
                marginLeft = (114 - newWidth)/2,
                marginTop = -10;

            $(this).css({
                marginTop: marginTop,
                marginLeft: marginLeft,
                height: 114,
                width: newWidth
            });

        }

        if(width > height){

            var newHeight = ( height/width ) * 114,
                marginTop = -13,
                marginLeft = 0;

            $(this).css({
                marginTop: marginTop,
                marginLeft: marginLeft,
                width: 114,
                height: newHeight
            });
        }
    });
}

function dialogDestroy(idTag){
    $(idTag+'_dialog-header').remove();
    $(idTag+' .dialogbox_body').remove(); 
    $(idTag).hide();
    $('#quarx-modal').fadeOut();
}

function inputDialogDestroy(idTag){
    $(idTag+'_dialog-header').remove();
    $(idTag+' .dialogbox_body_btns').remove(); 
    $(idTag).hide(); 
    $('#quarx-modal').fadeOut();
}

(function($){  
    $.fn.dialogbox = function(options) {

        $("html, body").animate({ scrollTop: 0 }, "slow");

        destroyDialogs();

        var defaults = {  
            ok: '',  
            buttons: {}
        };  
        options = $.extend(defaults, options);  

        var idTag = $(this).attr('id');
            coreTxt = $(this).html();
        
        /* Modal Part
        ***************************************************************/

        $('#quarx-modal').show();
        $('#quarx-modal').bind('click', function(){
            dialogDestroy('#'+idTag);
            $('#quarx-modal').fadeOut();
        });

        if(options.modal !== true){
            $('#quarx-modal').css('background', 'none');
        }else{
            $('#quarx-modal').css('background', '#333');
        }

        if($(this).attr('data-copy') > ''){
            coreTxt = $(this).attr('data-copy');
        }else{
            $(this).attr('data-copy', $(this).html());
        }

        if(options.buttons){

            $(this).html('');
            $(this).append('<div class="dialogbox_body"></div>');
            $('#'+idTag).prepend('<div class="dialogbox_header" id="'+idTag+'_dialog-header"><h1>'+$(this).attr('title')+'</h1></div>');
            $('#'+idTag+ ' .dialogbox_body').append(coreTxt);
            $('#'+idTag+ ' .dialogbox_body').append('<button data-theme="a" data-role="button" id="'+idTag+'_okBtn">Ok</button><button data-theme="a" data-role="button" id="'+idTag+'_CnclBtn">Cancel</button>').trigger('create');

            $('#'+idTag+'_okBtn').click( options.buttons.Ok );
            $('#'+idTag+'_CnclBtn').click( options.buttons.Cancel );

            if(!options.buttons.Ok){
                $('#'+idTag+'_okBtn').parent().remove();
            }

            if(!options.buttons.Cancel){
                $('#'+idTag+'_CnclBtn').parent().remove();
            }

        }

        $(this).css({
            left: ($(window).width() - 260)/2,
            top: (($(window).height() - $(this).height())/2) - 40
        });

        $(this).fadeIn();
    }  
})(jQuery);

(function($){  
    $.fn.dialogboxInput = function(options) {

        destroyDialogs();

        var defaults = {  
            ok: '',
            web_link: '',
            buttons: {}
        };  
        options = $.extend(defaults, options);  

        var idTag = $(this).attr('id'),
            coreTxt = $(this).html(),
            linkBox = '';

        inputDialogDestroy('#'+idTag);

        if($(this).attr('data-copy') > ''){
            coreTxt = $(this).attr('data-copy');
        }else{
            $(this).attr('data-copy', $(this).html());
        }

        if(options.web_link == false){
            linkBox = '';
        }else{
            linkBox = '<p>Web Link: <input value="'+options.web_link+'" /></p>';
        }

        $('#'+idTag).prepend('<div class="dialogbox_header" id="'+idTag+'_dialog-header"><h1>'+$(this).attr('title')+'</h1></div>');
        $('#'+idTag+ ' .dialogbox_body').append('<div class="dialogbox_body_btns">'+linkBox+'<button data-theme="a" data-role="button" id="'+idTag+'_okBtn">Ok</button><button data-theme="a" data-role="button" id="'+idTag+'_CnclBtn">Cancel</button></div>').trigger('create');

        $('#'+idTag+'_okBtn').click( options.buttons.Ok );
        $('#'+idTag+'_CnclBtn').click( options.buttons.Cancel );

        if(!options.buttons.Cancel){
            $('#'+idTag+'_CnclBtn').remove();
        }

        $(this).css({
            left: ($(window).width() - 260)/2,
            top: (($(window).height() - $(this).height())/2) - 40
        });

        $(this).fadeIn();
    }  
})(jQuery);

$(document).ready(function(){
    $(window).resize(function() {
        setTimeout(profileImageResize, 200);
    });
});

function destroyDialogs(){
    $('.dialogBox').hide();
}