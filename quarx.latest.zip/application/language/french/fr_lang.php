<?php

/* Filename: fr_lang.php
 * Location: languages/french
 * Author: Matt Lantz
 */

/* Index Page
***************************************************************/
$lang['welcome'] = 'Bienvenue sur le réseau';

?>