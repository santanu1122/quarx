<?php

/* Filename: de_lang.php
 * Location: languages/german
 * Author: Matt Lantz
 */

/* Index Page
***************************************************************/
$lang['welcome'] = 'Willkommen im Grid';

?>