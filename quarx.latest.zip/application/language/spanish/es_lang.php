<?php

/* Filename: es_lang.php
 * Location: languages/spanish
 * Author: Matt Lantz
 */

/* Index Page
***************************************************************/
$lang['welcome'] = 'Bienvenido a la Red';

?>