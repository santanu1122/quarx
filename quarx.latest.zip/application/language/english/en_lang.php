<?php

/* Filename: en_lang.php
 * Location: languages/english
 * Author: Matt Lantz
 */

/* Index Page
***************************************************************/
$lang['about title'] = 'About Us';

?>