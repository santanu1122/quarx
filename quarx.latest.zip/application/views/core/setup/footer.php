<?php /* 
	Filename: 	footer.php
	Location: 	/application/views/setup/
*/ ?>
        </div>
    </div>

        <div id="footer" data-role="footer" data-position="fixed" data-theme="a" class="align-center">
            <p>&copy; 2013 Matt Lantz</p>
        </div>
    </div>
    
</body>
</html>

<?php /* End of File */ ?>