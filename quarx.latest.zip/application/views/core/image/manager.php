<?php

/**
 * Quarx
 *
 * A modular application framework built on CodeIgniter
 *
 * @package     Quarx
 * @author      Matt Lantz
 * @copyright   Copyright (c) 2013 Matt Lantz
 * @license     http://ottacon.co/quarx/license.html
 * @link        http://ottacon.co/quarx
 * @since       Version 1.0
 * 
 */

?>

<!-- dialogs -->

<div id="dialog-img" title="Delete Confirmation" class="dialogBox">
    <div class="dialogbox_body">
        <p>Are you sure you want to delete this image collection?</p>
    </div>
</div>

<div id="dialog-newColl" class="dialogBox" title="New Collection">
    <div class="dialogbox_body">
        <input onfocus="this.value=''" data-theme="a" id="collectionName" type="text" value="Collection Name" />
    </div>
</div>

<!-- notifications -->

<div class="raw100">
    <div id="quarx-msg-box" class="<?php echo $state; ?>">
        <p><?php echo $message; ?></p>
    </div>
</div> 

<!-- main content -->

<?php $this->load->view("core/image/common/menu"); ?>

<div class="quarx-img-box align-center">
    <a id="newCollectionBtn" href="#" data-role="button" data-icon="plus" data-theme="a">New Collection</a>

    <?php foreach ($collection as $c) : ?>
        <a href="#" onclick="deleteMe(<?php echo $c->collection_id; ?>)" data-role="button" data-theme="e" data-icon="delete"><?php echo $c->collection_name; ?></a>
    <?php endforeach; ?>
</div>

<!-- javascript -->

<script type="text/javascript">

    $("#quarx-msg-box").fadeIn().delay(2500).fadeOut("slow");
    
    $(document).ready(function(e) {
        <?php if(isset($_GET['error'])){ ?>
            feedback('error');
        <?php } ?>

        <?php if(isset($_GET['success'])){ ?>
            feedback('success');
        <?php } ?>

        $('#newCollectionBtn').bind('click', function(){
            newCollectionBox();
        });
    });

    function newCollectionBox(){
        $( "#dialog-newColl" ).dialogboxInput({
            buttons: {
                Ok: function() {
                    $.ajax({
                        url: "<?php echo site_url('image/new_collection'); ?>",
                        type: 'POST',
                        cache: false,
                        data: { 
                            collection_name: $('#collectionName').val(),
                            <?php echo $this->security->get_csrf_token_name(); ?>: '<?php echo $this->security->get_csrf_hash(); ?>'
                        },
                        success: function(data) {
                            window.location = "<?php echo site_url('image/manager'); ?>";
                        }
                    });
                },
                Cancel: function() {
                    inputDialogDestroy("#dialog-newColl");
                }
            }
        });
    }

    function deleteMe(id) {
        $( "#dialog-img" ).dialogboxInput({
            buttons: {
                Ok: function() {
                    $.ajax({
                        url: "<?php echo site_url('image/delete_collection'); ?>",
                        type: 'POST',
                        data: { idTag: id,
                                <?php echo $this->security->get_csrf_token_name(); ?>: '<?php echo $this->security->get_csrf_hash(); ?>' 
                        },
                        success: function(msg) {
                            if(msg == 'true'){
                                window.location = "<?php echo site_url('image/manager'); ?>";   
                            }

                            if(msg == 'false'){
                                window.location = "<?php echo site_url('image/manager'); ?>"+"?error";   
                            }
                        }
                    });
                },
                Cancel: function() {
                    inputDialogDestroy( "#dialog-img" );
                }
            }
        });
    }

</script>

<!-- End of File -->