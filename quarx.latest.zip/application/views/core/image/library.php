<?php

/* Filename: library.php
 * Location: application/views/core/image
 */

?>

<div class="device">

    <iframe id="fullScreenImageLibrary" class="raw100" src="<?php echo site_url('image'); ?>" data-location="fullScreen"></iframe>

</div>