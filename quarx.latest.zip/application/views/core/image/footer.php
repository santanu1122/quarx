<?php /* 
	Filename: 	footer.php
	Location: 	/application/views/common/
*/ ?>

		</div>

	</div><!-- /big_box -->
    
</body>
</html>

<?php /* End of File */ ?>