<?php /*
	Filename: 	login_error.php
	Location: 	/application/views/core/
*/ ?>

<div class="smallDevice">
	<p>We regret to inform you but your not actually logged in....</p>
	<br />
	<br />
	<br />
	<a href="<?php echo site_url('login'); ?>" data-role="button">Login</a>
</div>
	
<?php /* End of File */ ?>