<?php /*
	Filename: 	passwordsent.php
	Location: 	/application/views/core/login
*/ ?>

<div class="raw100">
		
<div class="smallDevice">

	<p>A new password has successfully been sent to you. Please check it and then change it the next time you login.</p>
	<br />
	<br />
	<br />
	<button onclick="document.location='<?php echo site_url('login'); ?>'">Login</button>
</div>
	
<?php /* End of File */ ?>