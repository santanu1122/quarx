<?php /*
	Filename: 	insufficient.php
	Location: 	/application/views/core/
*/ ?>

<div class="raw100">
		
	<div class="smallDevice">

		<p>We regret to inform you that you do not have suffient permission to access this.</p>
		<br />
		<br />
		<br />
		<button data-role="button" onclick="document.location='<?php echo site_url('accounts'); ?>'">My Account</button>
	</div>

</div>
	
<?php /* End of File */ ?>