<?php

/**
 * Quarx
 *
 * A modular CMS built on CodeIgniter
 *
 * @package     Quarx
 * @author      Matt Lantz
 * @copyright   Copyright (c) 2013 Matt Lantz
 * @license     http://ottacon.co/quarx/license
 * @link        http://quarx.ottacon.co
 * @since       Version 1.0
 * 
 */

?>

<div class="raw100">
		
	<div class="smallDevice">

		<p>We regret to inform you that you do not have suffient permission to access this.</p>
		<br />
		<br />
		<br />
		<button data-role="button" onclick="document.location='<?php echo site_url('accounts'); ?>'">My Account</button>
	</div>

</div>
	
<?php /* End of File */ ?>