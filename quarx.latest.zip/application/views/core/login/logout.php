<?php /*
	Filename: 	logout.php
	Location: 	/application/views/core
*/ ?> 
	
<div class="smallDevice align-center">
	<br />
	<p>You are no longer signed in.</p>
	<br />
	<br />
	<a href="<?php echo site_url('login'); ?>" data-role="button">Sign In</a>
</div>
	
<?php //End of File ?>