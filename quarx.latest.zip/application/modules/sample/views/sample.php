<?php

/* Filename: sample.php
 * Location: /views/
 */

?>

<div class="device"><!-- content -->

<div class="raw50" style="min-height: 300px;">
    <h5 style="margin: 10px 0; color: #222;">Sample Module</h5>
    <hr />
</div>
<div class="raw50">
    <div class="padded" style="min-height: 500px;">
        <p>This is a sample module.</p>
    </div>
</div>

</div><!--/content -->

<?php //End of file ?>