<?php
//Load the default controller
$route['module_name'] = 'sample';