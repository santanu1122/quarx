<h2>Sample Settings</h2>

<form>

<div class="raw50">
    <input data-theme="a" id="sampleSetting" type="checkbox" value="1" name="sampleSetting" />
    <label for="sampleSetting">Sample Setting 1</label>
</div>

</form>